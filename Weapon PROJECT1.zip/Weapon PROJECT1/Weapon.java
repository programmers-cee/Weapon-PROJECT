public class Weapon {
	
	public void use() {
		System.out.println();
	}

}
