public class Knife extends Weapon{
	
	@Override
	public void use() {
		System.out.println("Use the Knife");
		System.out.println("Swing the Knife");
		System.out.println("Stab the Enemy");
		System.out.println("Kill the enemey!!");
	}

}
