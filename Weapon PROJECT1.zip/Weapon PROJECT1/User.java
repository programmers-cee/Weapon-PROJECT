import java.util.Scanner;
public class User {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		char c;
		Game g=new Game();
		do {
			Weapon w=g.selectWeapon();
			w.use();
			System.out.println("Press Y/y to continue...");
			c=sc.next().charAt(0);
		}while(c=='Y' || c=='y');
		System.out.println("=====Game Ends=====");
	}
}
